# coding=System
from REGISTER import *
from DEPARTMNT import *

class PROJECT (REGISTER):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  NUMER  (private)

   

  TOPIC  (private)

   

  DEPARMENT  (private)

  """

  def VIEW(self):
    """
     

    @return  :
    @author
    """
    pass



