# coding=System
from entrollment import *
from arms_site import *
from new_class import *

class login(object):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  username  (private)

   

  passwodr  (private)

   

  email_  (private)

  """

  def login(self):
    """
     

    @return  :
    @author
    """
    pass



