

/**
 * Class Login
 */
public class Login {

  //
  // Fields
  //

  private void Username;
  private void Password;
  private String User;
  private void Admin;
  
  //
  // Constructors
  //
  public Login () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of Username
   * @param newVar the new value of Username
   */
  private void setUsername (void newVar) {
    Username = newVar;
  }

  /**
   * Get the value of Username
   * @return the value of Username
   */
  private void getUsername () {
    return Username;
  }

  /**
   * Set the value of Password
   * @param newVar the new value of Password
   */
  private void setPassword (void newVar) {
    Password = newVar;
  }

  /**
   * Get the value of Password
   * @return the value of Password
   */
  private void getPassword () {
    return Password;
  }

  /**
   * Set the value of User
   * @param newVar the new value of User
   */
  private void setUser (String newVar) {
    User = newVar;
  }

  /**
   * Get the value of User
   * @return the value of User
   */
  private String getUser () {
    return User;
  }

  /**
   * Set the value of Admin
   * @param newVar the new value of Admin
   */
  private void setAdmin (void newVar) {
    Admin = newVar;
  }

  /**
   * Get the value of Admin
   * @return the value of Admin
   */
  private void getAdmin () {
    return Admin;
  }

  //
  // Other methods
  //

  /**
   */
  public void Login()
  {
  }


}
