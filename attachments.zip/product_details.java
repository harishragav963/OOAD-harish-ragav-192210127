

/**
 * Class product_details
 */
public class product_details {

  //
  // Fields
  //

  private int numbers;
  private int quality;
  private int review;
  
  //
  // Constructors
  //
  public product_details () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of numbers
   * @param newVar the new value of numbers
   */
  private void setNumbers (int newVar) {
    numbers = newVar;
  }

  /**
   * Get the value of numbers
   * @return the value of numbers
   */
  private int getNumbers () {
    return numbers;
  }

  /**
   * Set the value of quality
   * @param newVar the new value of quality
   */
  private void setQuality (int newVar) {
    quality = newVar;
  }

  /**
   * Get the value of quality
   * @return the value of quality
   */
  private int getQuality () {
    return quality;
  }

  /**
   * Set the value of review
   * @param newVar the new value of review
   */
  private void setReview (int newVar) {
    review = newVar;
  }

  /**
   * Get the value of review
   * @return the value of review
   */
  private int getReview () {
    return review;
  }

  //
  // Other methods
  //

  /**
   */
  public void search()
  {
  }


  /**
   */
  public void check()
  {
  }


  /**
   */
  public void view()
  {
  }


}
