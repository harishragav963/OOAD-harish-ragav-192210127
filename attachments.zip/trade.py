# coding=System
from biling import *

class sell_stock(object):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  details  (private)

   

  bulk  (private)

   

  type  (private)

  """

  def check(self):
    """
     

    @return  :
    @author
    """
    pass

  def view(self):
    """
     

    @return  :
    @author
    """
    pass



