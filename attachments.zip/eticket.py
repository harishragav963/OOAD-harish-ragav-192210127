# coding=System
from user import *
from database import *
from str import *

class login(object):

  """
   

  :version:
  :author:
  """

  """ ATTRIBUTES

   

  username  (private)

   

  password  (private)

  """

  def login(self):
    """
     

    @return  :
    @author
    """
    pass

  def logout(self):
    """
     

    @return  :
    @author
    """
    pass



